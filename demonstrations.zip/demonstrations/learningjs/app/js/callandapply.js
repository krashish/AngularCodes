var obj = {
    id: 10,
    name: 'Anand',
    initialAddress: 'Last Row',
    currentAddress: 'First Row',
    isActive: true
};

function process(inputA, inputB) {
    console.log(this.id + ', ' + this.name + ', ' + this.isActive + ', ' +
        inputA + ', ' + inputB);
}

process.call(obj, 10, 20);
process.apply(obj, [10, 20]);