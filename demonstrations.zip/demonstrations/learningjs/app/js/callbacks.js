function execute() {
    var result = 0;
    var callbacks = arguments;

    if (callbacks) {
        for (var index in callbacks) {
            var callback = callbacks[index];

            if (typeof callback === 'function') {
                result += callback(20, 20);
            }
        }
    }

    return function (x, y) {
        return result + x + y;
    };
}

var executeResult = execute(
    function (a, b) {
        return a + b;
    },
    function (a, b) {
        return a - b;
    },
    function (a, b) {
        return a * b;
    },
    function (a, b) {
        return a / b;
    });

console.log(executeResult(100, 100));