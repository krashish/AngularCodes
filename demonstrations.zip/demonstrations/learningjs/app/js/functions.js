function process() {
    var parameters = arguments;
    var index = 0;

    return function () {
        if (index < 0 || index >= parameters.length)
            throw new Error('Invalid Index Specified!');

        return parameters[index++];
    };
}

var iterator = process(10, 20, 30, 40, 50);

try {
    while (true) {
        console.log(iterator());
    }
} catch (error) {
    console.log('Error : ' + error.message);
} finally {
    console.log('End of the World!');
}