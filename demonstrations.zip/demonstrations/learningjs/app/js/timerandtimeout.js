function doProcess() {
    console.log('Processing ... ' +
        new Date().toString());
}

var timeOutId = setTimeout(doProcess, 4000);

clearTimeout(timeOutId);

var timer = setInterval(doProcess, 5000);

setTimeout(function () {
    if (timer) {
        clearInterval(timer);
    }
}, 11000);