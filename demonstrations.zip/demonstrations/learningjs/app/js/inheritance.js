function Customer(id, name, address, credit, status) {
    this.id = id;
    this.name = name;
    this.address = address;
    this.credit = credit;
    this.status = status;
}

Customer.prototype.format = function () {
    var formattedMessage = '';
    var delimiter = ', ';
    var noOfTrailCharacters = 2;

    for (var property in this) {
        if (typeof this[property] !== 'function') {
            formattedMessage += this[property] + delimiter;
        }
    }

    return formattedMessage.substr(0, formattedMessage.length - noOfTrailCharacters);
};

function InternetCustomer(id, name, address, credit, status, blogUrl) {
    Customer.apply(this, arguments);

    this.blogUrl = blogUrl;
}

InternetCustomer.prototype = new Customer();
InternetCustomer.prototype.constructor = InternetCustomer;

InternetCustomer.prototype.format = function () {
    var formattedMessage = Customer.prototype.format.apply(this);

    return formattedMessage.toUpperCase();
};

var customer = new InternetCustomer(
    10, 'Deepika', 'Bangalore', 12000, true, 'http://blogs.tecnotree.com/deepika');

console.log(customer instanceof Customer);
console.log(customer instanceof InternetCustomer);
console.log(InternetCustomer.prototype.constructor);
console.log(customer.format());