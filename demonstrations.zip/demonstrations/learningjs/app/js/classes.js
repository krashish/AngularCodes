function Customer(id, name, address, credit, status) {
    this.id = id;
    this.name = name;
    this.address = address;
    this.credit = credit;
    this.status = status;
}

Customer.prototype.format = function () {
    var formattedMessage = '';
    var delimiter = ', ';
    var noOfTrailCharacters = 2;

    for (var property in this) {
        if (typeof this[property] !== 'function') {
            formattedMessage += this[property] + delimiter;
        }
    }

    return formattedMessage.substr(0, formattedMessage.length - noOfTrailCharacters);
};

Customer.DELIMITER = ',';
Customer.create = function (csvString) {
    var customer = null;

    if (csvString) {
        var delimiter = ',';
        var splittedString = csvString.split(Customer.DELIMITER);

        customer = new Customer(
            splittedString[0],
            splittedString[1],
            splittedString[2],
            splittedString[3],
            splittedString[4]);
    }

    return customer;
};

var customer = Customer.create('10,Amit Kumar,First Row,12000,true');

console.log(customer instanceof Customer);
console.log(typeof customer);
console.log(customer.format());
