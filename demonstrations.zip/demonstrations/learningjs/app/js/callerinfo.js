function process() {
    console.log('Process Called ... ');

    var caller = process.caller;

    if(caller) {
        console.log('Caller Name : ' + caller.name);
    }
}

function processCaller() {
    console.log('Process Caller Started ...');

    process();
}

processCaller();