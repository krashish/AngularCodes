function Customer(id, name, address, credit, status) {
    this.id = id;
    this.name = name;
    this.address = address;
    this.credit = credit;
    this.status = status;
}

Customer.prototype.format = function () {
    var formattedMessage = '';
    var delimiter = ', ';
    var noOfTrailCharacters = 2;

    for (var property in this) {
        if (typeof this[property] !== 'function') {
            formattedMessage += this[property] + delimiter;
        }
    }

    return formattedMessage.substr(0, formattedMessage.length - noOfTrailCharacters);
};

var obj = {
    id: 10,
    name: 'Ramkumar',
    address: 'Bangalore',
    credit: 23000,
    status: true,
    locations: ['Bangalore', 'Chennai', 'Hyderabad'],
    work: function() {
        console.log('He does not work any longer ...');
    }
};

var jsonString = JSON.stringify(obj);
var parsedObject = JSON.parse(jsonString);

parsedObject.__proto__ = new Customer();

console.log(parsedObject.format());