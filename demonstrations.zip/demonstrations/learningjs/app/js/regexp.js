var PHONE_NUMBER_EXPRESSION = /^\d{5}-\d{5}$/;
var rajivPhoneNumber = '98880-34983';

console.log(PHONE_NUMBER_EXPRESSION.test(rajivPhoneNumber));